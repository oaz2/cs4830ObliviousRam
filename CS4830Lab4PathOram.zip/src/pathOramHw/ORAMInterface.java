package pathOramHw;

import java.util.ArrayList;


public interface ORAMInterface {
	
	public enum Operation {READ,WRITE};
	
	public byte[] access(Operation op, int blockIndex,byte[] newdata);

	public abstract int P(int leaf, int level);

	public abstract int[] getPositionMap();
	
	public abstract ArrayList<Block> getStash();

	public abstract int getStashSize();

	public int getNumLeaves();
	
	public int getNumLevels();
	
	public int getNumBlocks();
	
	/*get the number of buckets in the storage*/
	public int getNumBuckets();
	
}